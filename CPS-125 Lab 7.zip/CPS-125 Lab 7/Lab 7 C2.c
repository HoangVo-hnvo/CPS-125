#include <stdio.h>
#include <math.h>

int main(){

    FILE *fp;
    fp = fopen ("water.dat","r");
    return 0;
}
